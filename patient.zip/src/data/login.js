export const login_data = {
  email: 'test@patienthub.com',
  password: '123456'
}